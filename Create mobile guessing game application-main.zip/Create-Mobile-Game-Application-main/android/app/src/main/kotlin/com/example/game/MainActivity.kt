package com.example.game

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
